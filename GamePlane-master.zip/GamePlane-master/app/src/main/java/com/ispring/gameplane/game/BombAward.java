package com.ispring.gameplane.game;

import android.graphics.Bitmap;

/**
 * 炸弹奖励
 */
public class BombAward extends Award {

    public BombAward(Bitmap bitmap){
        super(bitmap);
    }

}