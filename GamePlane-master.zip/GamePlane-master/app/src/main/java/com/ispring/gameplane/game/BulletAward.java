package com.ispring.gameplane.game;

import android.graphics.Bitmap;

/**
 * 子弹奖励
 */
public class BulletAward extends Award {

    public BulletAward(Bitmap bitmap){
        super(bitmap);
    }

}
