package com.liyu.fakeweather;

/**
 * Created by liyu on 2016/10/31.
 */

public class AppGlobal {

    public static final String CURRENT_INDEX = "currentIndex";

}
