package com.liyu.fakeweather.event;

/**
 * Created by liyu on 2016/11/29.
 */

public class ThemeChangedEvent {

    public ThemeChangedEvent(int themeColor) {

    }
}
