package com.liyu.fakeweather.http;

import java.util.List;

/**
 * Created by liyu on 2016/10/31.
 */

public class BaseWeatherResponse<T> {

    public List<T> HeWeather5;
}
