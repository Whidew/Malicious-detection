package me.anany.weikandian;

/**
 * Created by anany on 16/1/12.
 *
 *      配置信息
 *
 * Email:zhujun2730@gmail.com
 */
public class Constants {
    public static final String DB_NAME = "weikandian";
    public static final String DB_NAME_ENCRYPTED = "weikandian_encrypted";
}
