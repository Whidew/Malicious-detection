package me.anany.weikandian.ui.fragment;

import me.anany.weikandian.R;
import me.anany.weikandian.base.BaseFragment;

/**
 * Created by anany on 16/1/6.
 * <p>
 * Email:zhujun2730@gmail.com
 */
public class DiscoverFragment extends BaseFragment {

    @Override
    protected int inflateLayoutId() {
        return R.layout.view_text;
    }
}
