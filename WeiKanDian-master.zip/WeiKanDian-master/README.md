# WeiKanDian
微看点Android客户端

![](./screenshot/device-2017-02-16-165622.png)

## 项目介绍

* OkHttp、Retrofit2.0 网络访问，RxJava 链式调用、线程切换
* Java8 Lambda 的简单使用
* FragmentTabHost 底部 Tab 切换
* GreenDao3.0 数据库本地缓存
* RecyclerView 实现首页新闻多 item 布局
* TabLayout 实现首页顶部 Tab 切换
* 顶部 Tab 切换的 adapter 实现了延迟加载、并复用了加载过的 Tab
* Glide 加载图片
* Robolectric 进行单元测试

## 关于
本项目是练手项目，尚未完善，本着可以学习较前沿的技术为目的。
